from typing import Callable, Optional
import torch
from torch import nn
from torch import Tensor
import torch.nn.functional as F
import numpy as np
import math
from math import sqrt

class SlidingWindowFusion(nn.Module):
    def __init__(self, win_size, stride, input_dim, output_dim):
        super().__init__()
        self.win_size = win_size
        self.stride = stride

        self.conv = nn.Conv1d(
            in_channels=win_size * input_dim,
            out_channels=output_dim,
            kernel_size=1,
            bias=False)

    def forward(self, x):
        x = x.unfold(dimension=1, size=self.win_size, step=self.stride)

        B, num_windows, win_size, d_model = x.shape

        x = torch.reshape(x, (B, num_windows, win_size * d_model))

        x = x.permute(0, 2, 1)

        x = self.conv(x)

        x = x.permute(0, 2, 1)

        return x

__all__ = ['Cross_Patch']

class Transpose(nn.Module):
    def __init__(self, *dims, contiguous=False):
        super().__init__()
        self.dims, self.contiguous = dims, contiguous

    def forward(self, x):
        if self.contiguous:
            return x.transpose(*self.dims).contiguous()
        else:
            return x.transpose(*self.dims)

def get_activation_fn(activation):
    if callable(activation):
        return activation()
    elif activation.lower() == "relu":
        return nn.ReLU()
    elif activation.lower() == "gelu":
        return nn.GELU()
    raise ValueError(f'{activation} is not available. You can use "relu", "gelu", or a callable')

def positional_encoding(pe, learn_pe, q_len, d_model):
    if pe == None:
        W_pos = torch.empty((q_len, d_model))
        nn.init.uniform_(W_pos, -0.02, 0.02)
        learn_pe = False
    elif pe == 'zero':
        W_pos = torch.empty((q_len, 1))
        nn.init.uniform_(W_pos, -0.02, 0.02)
    elif pe == 'zeros':
        W_pos = torch.empty((q_len, d_model))
        nn.init.uniform_(W_pos, -0.02, 0.02)
    elif pe == 'normal' or pe == 'gauss':
        W_pos = torch.zeros((q_len, 1))
        torch.nn.init.normal_(W_pos, mean=0.0, std=0.1)
    elif pe == 'uniform':
        W_pos = torch.zeros((q_len, 1))
        nn.init.uniform_(W_pos, a=0.0, b=0.1)
    elif pe == 'lin1d':
        W_pos = Coord1dPosEncoding(q_len, exponential=False, normalize=True)
    elif pe == 'exp1d':
        W_pos = Coord1dPosEncoding(q_len, exponential=True, normalize=True)
    elif pe == 'lin2d':
        W_pos = Coord2dPosEncoding(q_len, d_model, exponential=False, normalize=True)
    elif pe == 'exp2d':
        W_pos = Coord2dPosEncoding(q_len, d_model, exponential=True, normalize=True)
    elif pe == 'sincos':
        W_pos = PositionalEncoding(q_len, d_model, normalize=True)
    else:
        raise ValueError(f"{pe} is not a valid pe (positional encoder. Available types: 'gauss'=='normal', \
        'zeros', 'zero', uniform', 'lin1d', 'exp1d', 'lin2d', 'exp2d', 'sincos', None.)")
    return nn.Parameter(W_pos, requires_grad=learn_pe)

class Prediction_Head(nn.Module):
    def __init__(self, nf, target_window, head_dropout=0):
        super().__init__()

        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, target_window)
        self.dropout = nn.Dropout(head_dropout)

    def forward(self, x):
        x = self.flatten(x)
        x = self.linear(x)
        x = self.dropout(x)
        return x

class Cross_Patch_Encoder(nn.Module):
    def __init__(self, c_in, patch_num, patch_len, stride, win_size, drop_rate,
                 max_seq_len=1024, d_model=128, n_heads=16, d_k=None, d_v=None,
                 d_ff=256, norm='BatchNorm', attn_dropout=0.1, dropout=0.2, act="gelu",
                 key_padding_mask='auto', padding_var=None, attn_mask=None, res_attention=True,
                 pe='zeros', learn_pe=True, verbose=False, **kwargs, ):
        super().__init__()

        q_len = patch_num
        self.W_P = nn.Linear(patch_len, d_model)
        self.seq_len = q_len

        self.W_pos = positional_encoding(pe, learn_pe, q_len, d_model)

        self.dropout = nn.Dropout(dropout)

        self.win_size = win_size
        self.stride = stride

        self.conv1 = nn.Conv1d(in_channels=self.win_size * d_model, out_channels=d_model, kernel_size=1)
        self.conv2 = nn.Conv1d(in_channels=self.win_size * d_model, out_channels=d_model, kernel_size=1)

        self.layer2 = EncoderLayer(d_model, n_heads=n_heads, d_k=d_k, d_v=d_v, d_ff=d_ff, norm=norm,
                                   attn_dropout=attn_dropout, dropout=dropout,
                                   activation=act, res_attention=res_attention)
        self.layer3 = EncoderLayer(d_model, n_heads=n_heads, d_k=d_k, d_v=d_v, d_ff=d_ff, norm=norm,
                                   attn_dropout=attn_dropout, dropout=dropout,
                                   activation=act, res_attention=res_attention)
        self.GLD = GLD.GLD_FFN_Block(q_len, d_model, drop_rate=drop_rate)

        self.sliding_fusion1 = SlidingWindowFusion(
            win_size=win_size,
            stride=stride,
            input_dim=d_model,
            output_dim=d_model,
        )

        self.sliding_fusion2 = SlidingWindowFusion(
            win_size=win_size,
            stride=stride,
            input_dim=d_model,
            output_dim=d_model,
        )

    def forward(self, x, key_padding_mask: Optional[Tensor] = None,
                attn_mask: Optional[Tensor] = None) -> Tensor:
        n_vars = x.shape[1]

        x = self.W_P(x)
        u = torch.reshape(x, (x.shape[0] * x.shape[1], x.shape[2],
                              x.shape[3]))
        u = self.dropout(u + self.W_pos)

        z = self.GLD(u)

        z = self.sliding_fusion1(z)

        z = self.layer2(z, key_padding_mask=key_padding_mask, attn_mask=attn_mask)

        z = self.sliding_fusion2(z)

        z = self.layer3(z, key_padding_mask=key_padding_mask, attn_mask=attn_mask)

        z = torch.reshape(z, (-1, n_vars, z.shape[-2], z.shape[-1]))
        z = z.permute(0, 1, 3, 2)

        return z

class EncoderLayer(nn.Module):
    def __init__(self, d_model, n_heads, d_k=None, d_v=None, d_ff=256,
                 norm='BatchNorm', attn_dropout=0.1, dropout=0., bias=True, activation="gelu", res_attention=False):
        super().__init__()
        assert not d_model % n_heads, f"d_model ({d_model}) must be divisible by n_heads ({n_heads})"
        d_k = d_model // n_heads if d_k is None else d_k
        d_v = d_model // n_heads if d_v is None else d_v

        self.self_attn = _MultiheadAttention(d_model, n_heads, d_k, d_v, attn_dropout=attn_dropout,
                                             proj_dropout=dropout)
        self.dropout_attn = nn.Dropout(dropout)
        if "batch" in norm.lower():
            self.norm_attn = nn.Sequential(Transpose(1, 2), nn.BatchNorm1d(d_model), Transpose(1, 2))
        else:
            self.norm_attn = nn.LayerNorm(d_model)

        self.ff = nn.Sequential(nn.Linear(d_model, d_ff, bias=bias),
                                get_activation_fn(activation),
                                nn.Dropout(dropout),
                                nn.Linear(d_ff, d_model, bias=bias))

        self.dropout_ffn = nn.Dropout(dropout)
        if "batch" in norm.lower():
            self.norm_ffn = nn.Sequential(Transpose(1, 2), nn.BatchNorm1d(d_model), Transpose(1, 2))
        else:
            self.norm_ffn = nn.LayerNorm(d_model)

    def forward(self, src: Tensor, prev: Optional[Tensor] = None, key_padding_mask: Optional[Tensor] = None,
                attn_mask: Optional[Tensor] = None) -> Tensor:

        src2, attn = self.self_attn(src, src, src, key_padding_mask=key_padding_mask, attn_mask=attn_mask)

        src = src + self.dropout_attn(src2)
        src = self.norm_attn(src)

        src2 = self.ff(src)

        src = src + self.dropout_ffn(src2)
        src = self.norm_ffn(src)

        return src

class _MultiheadAttention(nn.Module):
    def __init__(self, d_model, n_heads, d_k=None, d_v=None, attn_dropout=0.1, proj_dropout=0.2, qkv_bias=True,
                 lsa=False):
        super().__init__()
        d_k = d_model // n_heads if d_k is None else d_k
        d_v = d_model // n_heads if d_v is None else d_v

        self.n_heads = n_heads
        self.d_k = d_k
        self.d_v = d_v

        self.inner_correlation = _ScaledDotProductAttention(d_model, n_heads)

        self.W_Q = nn.Linear(d_model, d_k * n_heads, bias=qkv_bias)
        self.W_K = nn.Linear(d_model, d_k * n_heads, bias=qkv_bias)
        self.W_V = nn.Linear(d_model, d_v * n_heads, bias=qkv_bias)

        self.to_out = nn.Sequential(nn.Linear(n_heads * d_v, d_model), nn.Dropout(proj_dropout))

    def forward(self, Q: Tensor, K: Optional[Tensor] = None, V: Optional[Tensor] = None, prev: Optional[Tensor] = None,
                key_padding_mask: Optional[Tensor] = None, attn_mask: Optional[Tensor] = None):
        bs = Q.size(0)
        if K is None: K = Q
        if V is None: V = Q

        queries = self.W_Q(Q).view(bs, -1, self.n_heads, self.d_k).transpose(1, 2)
        keys = self.W_K(K).view(bs, -1, self.n_heads, self.d_k).permute(0, 2, 3, 1)
        values = self.W_V(V).view(bs, -1, self.n_heads, self.d_v).transpose(1, 2)

        output, attn = self.inner_correlation(queries, keys, values, attn_mask)

        output = output.transpose(1, 2).contiguous().view(bs, -1, self.n_heads * self.d_v)
        output = self.to_out(output)
        return output, attn

class _ScaledDotProductAttention(nn.Module):
    def __init__(self, d_model, n_heads, attn_dropout=0.1, lsa=False):
        super().__init__()
        self.attn_dropout = nn.Dropout(attn_dropout)
        head_dim = d_model // n_heads
        self.scale = nn.Parameter(torch.tensor(head_dim ** -0.5), requires_grad=lsa)
        self.lsa = lsa

    def forward(self, q: Tensor, k: Tensor, v: Tensor, prev: Optional[Tensor] = None,
                key_padding_mask: Optional[Tensor] = None, attn_mask: Optional[Tensor] = None):

        attn_scores = torch.matmul(q, k) * self.scale

        if prev is not None: attn_scores = attn_scores + prev

        if attn_mask is not None:
            if attn_mask.dtype == torch.bool:
                attn_scores.masked_fill_(attn_mask, -np.inf)
            else:
                attn_scores += attn_mask

        if key_padding_mask is not None:
            attn_scores.masked_fill_(key_padding_mask.unsqueeze(1).unsqueeze(2), -np.inf)

        attn_weights = F.softmax(attn_scores, dim=-1)
        attn_weights = self.attn_dropout(attn_weights)

        output = torch.matmul(attn_weights, v)

        return output, attn_weights

class Cross_Patch(nn.Module):
    def __init__(self, c_in: int, context_window: int, target_window: int, patch_len: int, stride: int, win_size: int,
                 drop_rate: int,
                 max_seq_len: Optional[int] = 1024, d_model=128, n_heads=16, d_k: Optional[int] = None,
                 d_v: Optional[int] = None,
                 d_ff: int = 256, attn_dropout: float = 0., dropout: float = 0.,
                 act: str = "gelu", key_padding_mask: bool = 'auto',
                 padding_var: Optional[int] = None, attn_mask: Optional[Tensor] = None, res_attention: bool = True,
                 pe: str = 'zeros', learn_pe: bool = True, head_dropout=0, padding_patch=None, verbose: bool = False,
                 **kwargs):

        super().__init__()

        self.patch_len = patch_len
        self.stride = stride
        self.padding_patch = padding_patch

        patch_num = int((context_window - patch_len) / stride + 1)
        if padding_patch == 'end':
            self.padding_patch_layer = nn.ReplicationPad1d((0, stride))
            patch_num += 1

        win_num1 = int((patch_num - win_size) / stride + 1)
        win_num2 = int((win_num1 - win_size) / stride + 1)

        self.encoder_shared = Cross_Patch_Encoder(c_in, patch_num=patch_num, patch_len=patch_len, stride=stride,
                                                  win_size=win_size, drop_rate=drop_rate, max_seq_len=max_seq_len,
                                                  d_model=d_model, n_heads=n_heads, pe=pe, learn_pe=learn_pe, d_k=d_k,
                                                  d_v=d_v, d_ff=d_ff,
                                                  attn_dropout=attn_dropout, dropout=dropout, act=act,
                                                  key_padding_mask=key_padding_mask, padding_var=padding_var,
                                                  attn_mask=attn_mask, res_attention=res_attention, verbose=verbose,
                                                  **kwargs)

        self.head_nf = d_model * win_num2
        self.head = Prediction_Head(self.head_nf, target_window, head_dropout=head_dropout)

    def forward(self, z):
        if self.padding_patch == 'end':
            z = self.padding_patch_layer(z)
        z = z.unfold(dimension=-1, size=self.patch_len, step=self.stride)

        z = self.encoder_shared(z)

        z = self.head(z)

        return z

class Model(nn.Module):
    def __init__(self, configs, max_seq_len: Optional[int] = 1024, d_k: Optional[int] = None, d_v: Optional[int] = None,
                 norm: str = 'BatchNorm', attn_dropout: float = 0.,
                 act: str = "gelu", key_padding_mask: bool = 'auto', padding_var: Optional[int] = None,
                 attn_mask: Optional[Tensor] = None, res_attention: bool = True,
                 pre_norm: bool = False, store_attn: bool = False, pe: str = 'zeros', learn_pe: bool = True,
                 pretrain_head: bool = False, head_type='flatten', verbose: bool = False, **kwargs):
        super().__init__()
        self.pred_len = configs.pred_len
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len

        c_in = configs.enc_in
        context_window = configs.seq_len
        target_window = configs.pred_len
        label_len = configs.label_len
        n_heads = configs.n_heads
        d_model = configs.d_model
        d_ff = configs.d_ff
        dropout = configs.dropout
        fc_dropout = configs.fc_dropout
        head_dropout = configs.head_dropout

        patch_len = configs.patch_len
        stride = configs.stride
        win_size = configs.win_size
        drop_rate = configs.drop_rate
        padding_patch = configs.padding_patch
        revin = configs.revin
        affine = configs.affine
        subtract_last = configs.subtract_last

        self.model = Cross_Patch(c_in=c_in, context_window=context_window, target_window=target_window,
                                 patch_len=patch_len, stride=stride,
                                 win_size=win_size, drop_rate=drop_rate, max_seq_len=max_seq_len, d_model=d_model,
                                 label_len=label_len,
                                 n_heads=n_heads, d_k=d_k, d_v=d_v, d_ff=d_ff, norm=norm, attn_dropout=attn_dropout,
                                 dropout=dropout, act=act, key_padding_mask=key_padding_mask, padding_var=padding_var,
                                 attn_mask=attn_mask, res_attention=res_attention, pe=pe, learn_pe=learn_pe,
                                 fc_dropout=fc_dropout,
                                 head_dropout=head_dropout, padding_patch=padding_patch, head_type=head_type,
                                 revin=revin, affine=affine,
                                 subtract_last=subtract_last, verbose=verbose, **kwargs)

    def forward(self, x):
        mean = x.mean(1, keepdim=True).detach()
        x = x - mean
        std = torch.sqrt(torch.var(x, dim=1, keepdim=True, unbiased=False) + 1e-5).detach()
        x = x / std

        x = x.permute(0, 2, 1)

        x = self.model(x)
        x = x.permute(0, 2, 1)

        x = x * std + mean
        return x[:, -self.pred_len:, :]

def test_model():
    class Configs:
        def __init__(self):
            self.pred_len = 24
            self.seq_len = 104
            self.label_len = 168
            self.enc_in = 7
            self.n_heads = 4
            self.d_model = 16
            self.d_ff = 16
            self.dropout = 0.3
            self.fc_dropout = 0.3
            self.head_dropout = 0.0
            self.patch_len = 8
            self.stride = 2
            self.win_size = 4
            self.drop_rate = 0.3
            self.padding_patch = 'end'
            self.revin = 1
            self.affine = 0
            self.subtract_last = 0

    batch_size = 16
    seq_len = 104
    channels = 7

    x = torch.randn(batch_size, seq_len, channels)

    configs = Configs()
    model = Model(configs)

    with torch.no_grad():
        output = model(x)

if __name__ == "__main__":
    test_model()