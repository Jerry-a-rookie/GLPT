import torch
from torch import nn
import math
from einops import repeat, rearrange
from einops.layers.torch import Rearrange


# DLinear层实现（用于时间路径）
class DLinearLayer(nn.Module):
    def __init__(self, seq_len, d_model):
        """
        seq_len: 输入序列长度 (patch_num)
        d_model: 特征维度
        """
        super().__init__()
        self.seq_len = seq_len
        self.d_model = d_model

        # 趋势成分的线性层
        self.linear_trend = nn.Linear(seq_len, seq_len)
        # 季节性成分的线性层
        self.linear_seasonal = nn.Linear(seq_len, seq_len)

        # 初始化线性层权重
        for linear in [self.linear_trend, self.linear_seasonal]:
            nn.init.kaiming_normal_(linear.weight)
            nn.init.zeros_(linear.bias)

    def forward(self, x):
        """
        x: 输入张量 [batch_size, seq_len, d_model]
        输出: [batch_size, seq_len, d_model]
        """
        # 提取趋势成分 (使用移动平均)
        # 将特征维度移到前面以便进行池化
        x_t = x.permute(0, 2, 1)  # [batch_size, d_model, seq_len]

        # 使用平均池化提取趋势
        kernel_size = max(3, self.seq_len // 4)  # 动态调整核大小
        padding = kernel_size // 2
        trend = nn.functional.avg_pool1d(
            x_t, kernel_size=kernel_size, stride=1, padding=padding, count_include_pad=False
        )
        trend = trend.permute(0, 2, 1)  # [batch_size, seq_len, d_model]

        # 季节性成分 = 原始信号 - 趋势
        seasonal = x - trend

        # 分别处理趋势和季节性成分
        # 对每个特征维度独立处理
        trend_out = torch.zeros_like(trend)
        seasonal_out = torch.zeros_like(seasonal)

        for i in range(self.d_model):
            # 处理趋势成分
            trend_i = trend[..., i]  # [batch_size, seq_len]
            trend_out_i = self.linear_trend(trend_i)  # [batch_size, seq_len]
            trend_out[..., i] = trend_out_i

            # 处理季节性成分
            seasonal_i = seasonal[..., i]  # [batch_size, seq_len]
            seasonal_out_i = self.linear_seasonal(seasonal_i)  # [batch_size, seq_len]
            seasonal_out[..., i] = seasonal_out_i

        # 组合结果
        return trend_out + seasonal_out


# MLP块（用于变量路径）
class MLPBlock(nn.Module):
    def __init__(self, d_model, d_ff, dropout=0.1):
        super().__init__()
        self.fc1 = nn.Linear(d_model, d_ff)
        self.activation = nn.GELU()
        self.fc2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(d_model)

    def forward(self, x):
        residual = x
        x = self.fc1(x)
        x = self.activation(x)
        x = self.dropout(x)
        x = self.fc2(x)
        x = self.dropout(x)
        x = x + residual
        x = self.norm(x)
        return x


def positional_encoding(pe, learn_pe, q_len, d_model):
    # Positional encoding
    if pe == None:
        W_pos = torch.empty((q_len, d_model))
        nn.init.uniform_(W_pos, -0.02, 0.02)
        learn_pe = False
    elif pe == 'zero':
        W_pos = torch.empty((q_len, 1))
        nn.init.uniform_(W_pos, -0.02, 0.02)
    elif pe == 'zeros':
        W_pos = torch.empty((q_len, d_model))
        nn.init.uniform_(W_pos, -0.02, 0.02)
    elif pe == 'normal' or pe == 'gauss':
        W_pos = torch.zeros((q_len, 1))
        torch.nn.init.normal_(W_pos, mean=0.0, std=0.1)
    elif pe == 'uniform':
        W_pos = torch.zeros((q_len, 1))
        nn.init.uniform_(W_pos, a=0.0, b=0.1)
    else:
        raise ValueError(f"{pe} is not a valid pe (positional encoder. Available types: 'gauss'=='normal', \
        'zeros', 'zero', uniform', 'lin1d', 'exp1d', 'lin2d', 'exp2d', 'sincos', None.)")
    return nn.Parameter(W_pos, requires_grad=learn_pe)


class FlattenHead(nn.Module):
    def __init__(self, n_vars, nf, target_window, head_dropout=0):
        super().__init__()
        self.individual = False
        self.n_vars = n_vars
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, target_window)
        self.dropout = nn.Dropout(head_dropout)

    def forward(self, x):
        x = self.flatten(x)
        x = self.linear(x)
        x = self.dropout(x)
        return x


# 交叉注意力融合模块
class CrossAttentionFusion(nn.Module):
    def __init__(self, d_model, n_heads=4, dropout=0.1):
        super().__init__()
        self.n_heads = n_heads
        self.d_model = d_model
        self.head_dim = d_model // n_heads

        assert self.head_dim * n_heads == d_model, "d_model must be divisible by n_heads"

        # 投影层
        self.w_q = nn.Linear(d_model, d_model)
        self.w_k = nn.Linear(d_model, d_model)
        self.w_v = nn.Linear(d_model, d_model)
        self.fc = nn.Linear(d_model, d_model)

        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(d_model)

    def forward(self, x1, x2):
        """
        x1: 第一组特征 [b, c, l, d]
        x2: 第二组特征 [b, c, l, d]
        """
        b, c, l, d = x1.shape

        # 重排为注意力需要的形状
        x1 = rearrange(x1, 'b c l d -> (b l) c d')  # [b*l, c, d]
        x2 = rearrange(x2, 'b c l d -> (b l) c d')  # [b*l, c, d]

        # 第一组作为Q，第二组作为K,V
        Q = self.w_q(x1).view(b * l, c, self.n_heads, self.head_dim).transpose(1, 2)
        K = self.w_k(x2).view(b * l, c, self.n_heads, self.head_dim).transpose(1, 2)
        V = self.w_v(x2).view(b * l, c, self.n_heads, self.head_dim).transpose(1, 2)

        # 计算注意力
        attn_scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn_weights = torch.softmax(attn_scores, dim=-1)
        attn_weights = self.dropout(attn_weights)

        attn_output1 = torch.matmul(attn_weights, V)
        attn_output1 = attn_output1.transpose(1, 2).contiguous().view(b * l, c, d)
        attn_output1 = self.fc(attn_output1)

        # 第二组作为Q，第一组作为K,V
        Q = self.w_q(x2).view(b * l, c, self.n_heads, self.head_dim).transpose(1, 2)
        K = self.w_k(x1).view(b * l, c, self.n_heads, self.head_dim).transpose(1, 2)
        V = self.w_v(x1).view(b * l, c, self.n_heads, self.head_dim).transpose(1, 2)

        # 计算注意力
        attn_scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn_weights = torch.softmax(attn_scores, dim=-1)
        attn_weights = self.dropout(attn_weights)

        attn_output2 = torch.matmul(attn_weights, V)
        attn_output2 = attn_output2.transpose(1, 2).contiguous().view(b * l, c, d)
        attn_output2 = self.fc(attn_output2)

        # 平均两个注意力输出
        attn_output = (attn_output1 + attn_output2) / 2
        attn_output = self.layer_norm(attn_output)

        # 恢复原始形状
        attn_output = rearrange(attn_output, '(b l) c d -> b c l d', b=b, l=l)
        return attn_output


class Model(nn.Module):
    def __init__(self, configs):
        super().__init__()
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.patch_len = configs.patch_len
        self.stride = configs.stride

        # 计算块数量
        self.patch_num = int((configs.seq_len - self.patch_len) / self.stride + 1)
        self.padding_patch_layer = nn.ReplicationPad1d((0, self.stride))
        self.patch_num += 1  # 考虑填充后增加的块

        self.e_layers = configs.e_layers
        self.d_layers = configs.d_layers
        self.d_model = configs.d_model
        self.n_vars = configs.enc_in

        # 块嵌入层
        self.W_P = nn.Linear(self.patch_len, self.d_model)
        # 位置编码
        self.W_pos = positional_encoding('zero', True, self.patch_num, self.d_model)

        # 时间路径使用DLinear
        self.encoder_time = nn.ModuleList()
        for _ in range(configs.e_layers):
            self.encoder_time.append(
                DLinearLayer(self.patch_num, self.d_model)
            )

        # 变量路径使用MLP
        self.encoder_var = nn.ModuleList()
        for _ in range(configs.d_layers):
            self.encoder_var.append(
                MLPBlock(configs.d_model, configs.d_ff, configs.dropout)
            )

        # 预测头
        self.head_nf = configs.d_model * self.patch_num
        self.head = FlattenHead(self.n_vars, self.head_nf, configs.pred_len)

        # 特征融合模块
        self.ff = nn.Sequential(
            nn.Linear(configs.d_model * 2, configs.d_model),
            nn.GELU(),
            nn.Dropout(configs.dropout),
            nn.Linear(configs.d_model, configs.d_model)
        )

        # 归一化层
        self.norm = nn.LayerNorm(configs.d_model)
        self.norm_v = nn.LayerNorm(configs.d_model)

        # 交叉注意力特征融合模块
        self.cross_attn_fusion = CrossAttentionFusion(configs.d_model)

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        b, _, n_vars = x_enc.shape

        # 输入归一化 (RevIN)
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5).detach()
        x_enc /= stdev

        # 数据分块和嵌入
        x = x_enc.permute(0, 2, 1)  # [b, n_vars, seq_len]
        x = self.padding_patch_layer(x)  # [b, n_vars, seq_len + stride]

        # 分割为块 [b, n_vars, patch_num, patch_len]
        x = x.unfold(dimension=-1, size=self.patch_len, step=self.stride)

        # 嵌入到d_model维度
        enc_in = self.W_P(x)  # [b, n_vars, patch_num, d_model]

        # 时间路径处理
        if self.e_layers != 0:
            # 重塑为 [b*n_vars, patch_num, d_model]
            enc_in_time = rearrange(enc_in, 'b c l d -> (b c) l d')
            enc_in_time = enc_in_time + self.W_pos  # 添加位置编码

            # 通过DLinear块处理时间序列
            hidden_states_time = enc_in_time
            residual_time = hidden_states_time
            for layer in self.encoder_time:
                hidden_states_time = layer(hidden_states_time)
                # 残差连接
                hidden_states_time = hidden_states_time + residual_time
                residual_time = hidden_states_time

            # 归一化
            enc_out_time = self.norm(hidden_states_time)
            enc_out_time = rearrange(enc_out_time, '(b c) l d -> b c l d',
                                     b=b, c=n_vars, l=self.patch_num, d=self.d_model)
        else:
            enc_out_time = None

        # 变量路径处理
        if self.d_layers != 0:
            # 重塑为 [b*patch_num, n_vars, d_model]
            enc_in_var = rearrange(enc_in, 'b c l d -> (b l) c d')

            # 通过MLP块处理变量关系
            hidden_states_var = enc_in_var
            for layer in self.encoder_var:
                hidden_states_var = layer(hidden_states_var)

            enc_out_var = rearrange(hidden_states_var, '(b l) c d -> b c l d',
                                    b=b, c=n_vars, l=self.patch_num, d=self.d_model)
        else:
            enc_out_var = None

        # 特征融合 - 使用交叉注意力机制
        if enc_out_time is not None and enc_out_var is not None:
            # 使用交叉注意力融合两个分支的特征
            enc_out = self.cross_attn_fusion(enc_out_time, enc_out_var)
        elif enc_out_time is not None:
            enc_out = enc_out_time
        else:
            enc_out = enc_out_var

        # 预测头处理
        enc_out = rearrange(enc_out, 'b c l d -> b c d l')
        dec_out = self.head(enc_out)
        dec_out = dec_out.permute(0, 2, 1)  # [b, pred_len, n_vars]

        # 反归一化
        dec_out = dec_out * (stdev[:, [0], :].repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, [0], :].repeat(1, self.pred_len, 1))
        return dec_out

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]  # [B, L, D]


def test_model():
    # 定义模拟配置
    class Config:
        def __init__(self):
            self.seq_len = 96
            self.pred_len = 24
            self.patch_len = 16
            self.stride = 8
            self.enc_in = 8  # 变量数量
            self.d_model = 64
            self.e_layers = 2
            self.d_layers = 2
            self.d_ff = 128
            self.dropout = 0.1
            # 保留Mamba相关参数避免报错（实际不使用）
            self.d_state1 = 16
            self.d_state2 = 16
            self.use_act = True

    # 创建配置实例
    config = Config()

    # 初始化模型
    model = Model(config)
    print(f"模型参数量: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

    # 创建模拟输入数据
    batch_size = 4
    x_enc = torch.randn(batch_size, config.seq_len, config.enc_in)  # 输入序列
    x_mark_enc = torch.zeros(batch_size, config.seq_len, 0)  # 空时间特征
    x_dec = torch.randn(batch_size, config.pred_len, config.enc_in)  # 解码器输入
    x_mark_dec = torch.zeros(batch_size, config.pred_len, 0)  # 空时间特征

    # 前向传播测试
    output = model(x_enc, x_mark_enc, x_dec, x_mark_dec)
    print(f"输入形状: enc={x_enc.shape}, dec={x_dec.shape}")
    print(f"输出形状: {output.shape}")

    # 验证输出形状
    assert output.shape == (batch_size, config.pred_len, config.enc_in), \
        f"输出形状错误: 期望{(batch_size, config.pred_len, config.enc_in)}, 实际{output.shape}"

    print("\n示例输出 (第一个样本的第一个时间步):")
    print(output[0, 0].detach().numpy())

    return model, output


# 运行测试
if __name__ == "__main__":
    model, output = test_model()
    print("测试通过！模型运行正常。")