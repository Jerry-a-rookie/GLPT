import torch
import torch.nn as nn


class ConvFFN_FeatureExtractor(nn.Module):
    """仅包含ConvFFN1和ConvFFN2的特征提取器"""

    def __init__(self, nvars, dmodel, dff, drop=0.1):
        super(ConvFFN_FeatureExtractor, self).__init__()
        self.nvars = nvars
        self.dmodel = dmodel

        # ConvFFN1: 特征维度混合
        self.ffn1pw1 = nn.Conv1d(
            in_channels=nvars * dmodel,
            out_channels=nvars * dff,
            kernel_size=1,
            groups=nvars
        )
        self.ffn1act = nn.GELU()
        self.ffn1pw2 = nn.Conv1d(
            in_channels=nvars * dff,
            out_channels=nvars * dmodel,
            kernel_size=1,
            groups=nvars
        )
        self.ffn1drop1 = nn.Dropout(drop)
        self.ffn1drop2 = nn.Dropout(drop)

        # ConvFFN2: 变量维度混合
        self.ffn2pw1 = nn.Conv1d(
            in_channels=nvars * dmodel,
            out_channels=nvars * dff,
            kernel_size=1,
            groups=dmodel
        )
        self.ffn2act = nn.GELU()
        self.ffn2pw2 = nn.Conv1d(
            in_channels=nvars * dff,
            out_channels=nvars * dmodel,
            kernel_size=1,
            groups=dmodel
        )
        self.ffn2drop1 = nn.Dropout(drop)
        self.ffn2drop2 = nn.Dropout(drop)

    def forward(self, x):
        """
        输入: [B, M, D, N] (batch, num_vars, feature_dim, seq_len)
        输出: [B, M, D, N] 形状不变
        """
        B, M, D, N = x.shape

        # ConvFFN1 处理
        x_reshaped = x.reshape(B, M * D, N)
        x_reshaped = self.ffn1drop1(self.ffn1pw1(x_reshaped))
        x_reshaped = self.ffn1act(x_reshaped)
        x_reshaped = self.ffn1drop2(self.ffn1pw2(x_reshaped))
        x_reshaped = x_reshaped.reshape(B, M, D, N)

        # ConvFFN2 处理
        x_permuted = x_reshaped.permute(0, 2, 1, 3).reshape(B, D * M, N)
        x_permuted = self.ffn2drop1(self.ffn2pw1(x_permuted))
        x_permuted = self.ffn2act(x_permuted)
        x_permuted = self.ffn2drop2(self.ffn2pw2(x_permuted))
        x_out = x_permuted.reshape(B, D, M, N).permute(0, 2, 1, 3)

        return x_out


# 使用示例
if __name__ == "__main__":
    # 配置参数
    nvars = 7  # 变量数量
    dmodel = 64  # 特征维度
    dff = 256  # FFN中间维度
    drop = 0.1

    # 创建特征提取器
    model = ConvFFN_FeatureExtractor(nvars, dmodel, dff, drop)

    # 测试输入 [batch, num_vars, feature_dim, seq_len]
    test_input = torch.randn(32, nvars, dmodel, 100)

    # 前向传播
    output = model(test_input)

    print("输入形状:", test_input.shape)
    print("输出形状:", output.shape)

    # 验证形状一致性
    assert output.shape == test_input.shape
    print("测试通过！输入输出形状一致。")