import torch
import torch.nn as nn


class EmbLayer(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size):
        super(EmbLayer, self).__init__()
        self.kernel_size = kernel_size
        self.conv = nn.Conv1d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=kernel_size,
            stride=1,
            padding=0
        )
        # 计算左右填充量以保持序列长度不变
        self.pad_left = (kernel_size - 1) // 2
        self.pad_right = (kernel_size - 1) - self.pad_left

    def forward(self, x):
        # x 形状: (batch_size, seq_len, in_channels)
        x = x.permute(0, 2, 1)  # 转换为 (batch_size, in_channels, seq_len)
        # 应用反射填充以保持序列长度
        x = nn.functional.pad(x, (self.pad_left, self.pad_right), mode='replicate')
        x = self.conv(x)  # 输出形状: (batch_size, out_channels, seq_len)
        return x


class Emb(nn.Module):
    def __init__(self, seq_len, d_model, patch_len=[24, 12, 6, 4]):
        super(Emb, self).__init__()
        d_model_out = d_model // 4  # 每个EmbLayer的输出通道数

        # 创建四个EmbLayer，每个使用不同的卷积核大小
        self.EmbLayer_1 = EmbLayer(in_channels=d_model, out_channels=d_model_out, kernel_size=patch_len[0])
        self.EmbLayer_2 = EmbLayer(in_channels=d_model, out_channels=d_model_out, kernel_size=patch_len[1])
        self.EmbLayer_3 = EmbLayer(in_channels=d_model, out_channels=d_model_out, kernel_size=patch_len[2])
        self.EmbLayer_4 = EmbLayer(in_channels=d_model, out_channels=d_model_out, kernel_size=patch_len[3])

    def forward(self, x):
        # 输入 x 形状: (batch_size, seq_len, d_model)
        s_x1 = self.EmbLayer_1(x)  # 输出形状: (batch_size, d_model_out, seq_len)
        s_x2 = self.EmbLayer_2(x)
        s_x3 = self.EmbLayer_3(x)
        s_x4 = self.EmbLayer_4(x)

        # 在通道维度上拼接
        s_out = torch.cat([s_x1, s_x2, s_x3, s_x4], dim=1)  # 形状: (batch_size, d_model, seq_len)
        return s_out


# 测试函数保持不变
def test_emb():
    torch.manual_seed(42)
    seq_len = 100
    channels = 256
    emb_model = Emb(seq_len, channels)

    batch_size = 32
    input_tensor = torch.randn(batch_size, seq_len, channels)

    output = emb_model(input_tensor)
    print(f"Output shape: {output.shape}")

    expected_output_shape = (batch_size, channels, seq_len)
    assert output.shape == expected_output_shape, f"Expected {expected_output_shape}, got {output.shape}"
    print("Test passed.")


test_emb()