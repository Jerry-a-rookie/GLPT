from typing import Callable, Optional
import torch
from torch import nn
from torch import Tensor
import torch.nn.functional as F
import numpy as np
from layers import GLD

class SlidingWindowFusion(nn.Module):

    def __init__(self, win_size, stride, input_dim, output_dim):
        super().__init__()
        self.win_size = win_size
        self.stride = stride

        self.conv = nn.Conv1d(
            in_channels=win_size * input_dim,
            out_channels=output_dim,
            kernel_size=1,
            bias=False)

    def forward(self, x):
        x = x.unfold(dimension=1, size=self.win_size, step=self.stride)

        B, num_windows, win_size, d_model = x.shape

        x = torch.reshape(x, (B, num_windows, win_size * d_model))

        x = x.permute(0, 2, 1)

        x = self.conv(x)

        x = x.permute(0, 2, 1)

        return x

batch_size = 4
seq_len = 20
d_model = 8

x = torch.randn(batch_size, seq_len, d_model)
print(f"Input shape: {x.shape}")

win_size = 5
stride = 2
output_dim = 16

fusion_module = SlidingWindowFusion(
    win_size=win_size,
    stride=stride,
    input_dim=d_model,
    output_dim=output_dim
)

output = fusion_module(x)

new_seq_len = (seq_len - win_size) // stride + 1
print(f"Output shape: {output.shape}")

assert output.shape == (batch_size, new_seq_len, output_dim), "Output shape does not match expected"

print("Module runs successfully!")
print(f"Input: {x.shape} -> Sliding window fusion -> Output: {output.shape}")
print(f"Window size: {win_size}, stride: {stride}")
print(f"Each window fuses {win_size}×{d_model}={win_size*d_model} dimensional features into {output_dim} dimensional features")