import torch
import torch.nn as nn
import torch.nn.functional as F

class t1attention(nn.Module):
    def __init__(self, seq_len, reduction=2):
        super().__init__()
        self.ta = nn.Sequential(
            nn.Linear(seq_len, seq_len // reduction, bias=False),
            nn.ReLU(),
            nn.Linear(seq_len // reduction, seq_len, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        x_pool = x.mean(dim=-1)
        weights = self.ta(x_pool)
        return weights.unsqueeze(-1) * x

class t2attention(nn.Module):
    def __init__(self, kernel_size=7):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(2, 1, kernel_size, padding=kernel_size // 2, bias=False),
            nn.BatchNorm1d(1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x_perm = x.permute(0, 2, 1)
        avg_out = torch.mean(x_perm, dim=1, keepdim=True)
        max_out, _ = torch.max(x_perm, dim=1, keepdim=True)
        combined = torch.cat([avg_out, max_out], dim=1)
        weights = self.conv(combined)
        weights = weights.permute(0, 2, 1)
        return weights * x

class MultiScaleConv(nn.Module):
    def __init__(self, d_model, drop_rate, kernels=[1, 3, 5], reduction=4):
        super().__init__()
        self.branches = nn.ModuleList()

        for k in kernels:
            conv = nn.Sequential(
                nn.Conv1d(
                    in_channels=d_model,
                    out_channels=d_model,
                    kernel_size=k,
                    padding=k // 2,
                    groups=d_model,
                    bias=False
                ),
                nn.GELU(),
                nn.Dropout(drop_rate)
            )
            self.branches.append(conv)

        self.channel_attention = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(d_model, d_model // reduction, bias=False),
            nn.ReLU(),
            nn.Linear(d_model // reduction, d_model, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        residual = x
        x_conv = x.permute(0, 2, 1)

        branch_outputs = []
        for branch in self.branches:
            out = branch(x_conv)
            branch_outputs.append(out)

        fused = torch.stack(branch_outputs, dim=-1)
        fused = torch.mean(fused, dim=-1)

        channel_weights = self.channel_attention(fused)
        channel_weights = channel_weights.unsqueeze(-1)

        weighted = fused * channel_weights
        output = weighted.permute(0, 2, 1)
        return output + residual

class GLD_FFN_Block(nn.Module):
    def __init__(self, seq_len, d_model=64, drop_rate=0.3, reduction=16, kernels=[3, 5, 7]):
        super().__init__()
        self.t1 = t1attention(seq_len, reduction)
        self.t2 = t2attention()
        self.multiscale = MultiScaleConv(d_model, drop_rate, kernels)

        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.beta = nn.Parameter(torch.tensor(0.5))
        nn.init.constant_(self.alpha, 0.5)
        nn.init.constant_(self.beta, 0.5)

    def forward(self, x):
        identity = x
        t1 = self.t1(x)
        ms = self.multiscale(x)
        fused = self.alpha * t1 + self.beta * ms
        out = fused + identity
        return out
